package com.srajan.flightreservation.dto;

public class ReservationUpdateRequest {

	private Long id;
	private int numberOfBags;
	private Boolean checkedIn;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public int getNumberOfBags() {
		return numberOfBags;
	}

	public void setNoOfBags(int numberOfBags) {
		this.numberOfBags = numberOfBags;
	}

	public Boolean getCheckedIn() {
		return checkedIn;
	}

	public void setCheckedIn(Boolean checkedIn) {
		this.checkedIn = checkedIn;
	}
}

package com.srajan.flightreservation.services;

public interface SecurityService {

	boolean login(String username, String password);
}

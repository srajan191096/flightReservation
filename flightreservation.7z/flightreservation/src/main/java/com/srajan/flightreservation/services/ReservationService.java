package com.srajan.flightreservation.services;

import com.srajan.flightreservation.dto.ReservationRequest;
import com.srajan.flightreservation.entities.Reservation;
import com.srajan.flightreservation.repos.ReservationRepository;

public interface ReservationService {

	public Reservation bookFlight(ReservationRequest request);
	
}
